package com.codycornell82.minecraftPlus.PowerBlocks;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;

public class SlotInfuser extends Slot {

	public SlotInfuser(EntityPlayer player, IInventory iinventory, int i,
			int j, int k) {
		super(iinventory, i, j, k);

	}

}
