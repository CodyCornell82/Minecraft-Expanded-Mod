package com.codycornell82.minecraftPlus;

import net.minecraft.item.ItemAxe;

public class Steelaxe extends ItemAxe {

	protected Steelaxe(ToolMaterial p_i45327_1_) {
		super(p_i45327_1_);
		// TODO Auto-generated constructor stub
	}

}
