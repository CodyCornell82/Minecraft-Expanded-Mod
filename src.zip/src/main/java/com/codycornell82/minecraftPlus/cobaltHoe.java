package com.codycornell82.minecraftPlus;

import net.minecraft.item.ItemHoe;

public class cobaltHoe extends ItemHoe {

	public cobaltHoe(ToolMaterial p_i45343_1_) {
		super(p_i45343_1_);

	}

}
