package com.codycornell82.minecraftPlus;

import net.minecraft.item.ItemPickaxe;

public class cobaltPickaxe extends ItemPickaxe {

	protected cobaltPickaxe(ToolMaterial p_i45347_1_) {
		super(p_i45347_1_);

	}

}
