package com.codycornell82.minecraftPlus;

import net.minecraft.item.ItemSpade;

public class cobaltShovel extends ItemSpade {

	public cobaltShovel(ToolMaterial p_i45353_1_) {
		super(p_i45353_1_);

	}

}
