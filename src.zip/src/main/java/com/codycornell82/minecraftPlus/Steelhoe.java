package com.codycornell82.minecraftPlus;

import net.minecraft.item.ItemHoe;

public class Steelhoe extends ItemHoe {

	public Steelhoe(ToolMaterial p_i45343_1_) {
		super(p_i45343_1_);
		// TODO Auto-generated constructor stub
	}

}
