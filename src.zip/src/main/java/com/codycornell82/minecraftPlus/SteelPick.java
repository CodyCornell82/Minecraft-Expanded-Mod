package com.codycornell82.minecraftPlus;

import net.minecraft.item.ItemPickaxe;

public class SteelPick extends ItemPickaxe {

	protected SteelPick(ToolMaterial p_i45347_1_) {
		super(p_i45347_1_);
		// TODO Auto-generated constructor stub
	}

}
