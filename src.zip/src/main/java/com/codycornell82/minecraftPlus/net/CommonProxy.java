package com.codycornell82.minecraftPlus.net;

public class CommonProxy {

	public void registerRenderThings() {

	}

	public void registerTileEntitySpecialRenderer() {

	}

}
