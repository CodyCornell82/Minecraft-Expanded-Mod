package com.codycornell82.minecraftPlus;

import java.util.Set;

import net.minecraft.item.Item;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemTool;

public class TransformationWand extends ItemSpade {

	protected TransformationWand(ToolMaterial p_i45333_2_) {
		super(p_i45333_2_);

	}

}
