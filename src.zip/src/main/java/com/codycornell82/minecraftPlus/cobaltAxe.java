package com.codycornell82.minecraftPlus;

import net.minecraft.item.ItemAxe;

public class cobaltAxe extends ItemAxe {

	protected cobaltAxe(ToolMaterial p_i45327_1_) {
		super(p_i45327_1_);

	}

}
